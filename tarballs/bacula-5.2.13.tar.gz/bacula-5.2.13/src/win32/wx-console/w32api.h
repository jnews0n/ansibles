#ifndef _W32API_H_
#define _W32API_H_
#if __GNUC__ >=3
#pragma GCC system_header
#endif

#define __W32API_VERSION 2.4
#define __W32API_MAJOR_VERSION 2
#define __W32API_MINOR_VERSION 4

#endif /* ndef _W32API_H_ */
